//import mongo collections, bcrypt and implement the following data functions
export const createUser = async (
  firstName,
  lastName,
  emailAddress,
  password,
  role
) => {};

export const checkUser = async (emailAddress, password) => {};
