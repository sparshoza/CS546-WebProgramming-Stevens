/* Todo: Implment the functions below and then export them
      using the ES6 exports syntax. 
      DO NOT CHANGE THE FUNCTION NAMES
*/

let sortAndFilter = (array, sortBy1, sortBy2, filterBy, filterByTerm) => {};

let merge = (...args) => {
  //this function takes in a variable number of arrays that's what the ...args signifies
};

let matrixMultiply = (...args) => {
    //this function takes in a variable number of arrays that's what the ...args signifies
};

