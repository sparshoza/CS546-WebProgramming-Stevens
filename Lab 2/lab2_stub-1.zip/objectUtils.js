/* Todo: Implment the functions below and then export them
      using the ES6 exports syntax. 
      DO NOT CHANGE THE FUNCTION NAMES
*/

let areObjectsEqual = (...args) => {
      //this function takes in a variable number of objects that's what the ...args signifies
};

let calculateObject = (object, funcs) => {};

let combineObjects = (...args) => {
      //this function takes in a variable number of objects that's what the ...args signifies
};
