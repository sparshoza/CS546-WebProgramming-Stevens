/* Todo: Implment the functions below and then export them
      using the ES6 exports syntax. 
      DO NOT CHANGE THE FUNCTION NAMES
*/

let palindromes = (string) => {};

let censorWords = (string, badWordsList) => {};

let distance = (string, word1, word2) => {};
