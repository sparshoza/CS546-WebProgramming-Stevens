//TODO EXPORT AND IMPLEMENT THE FOLLOWING FUNCTIONS IN ES6 FORMAT
//User data link: https://gist.githubusercontent.com/jdelrosa/381cbe8fae75b769a1ce6e71bdb249b5/raw/564a41f84ab00655524a8cbd9f30b0409836ee39/users.json
const getUserById = async (id) => {};

const sameGenre = async (genre) => {};

const moviesReviewed = async (id) => {};

const referMovies = async (id) => {};
