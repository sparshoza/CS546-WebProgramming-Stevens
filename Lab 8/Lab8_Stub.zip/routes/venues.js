//Import express and express router as shown in lecture code and worked in previous labs
//You can make your axios calls to the API directly in the routes
router.route('/').get(async (req, res) => {
  //code here for GET
});

router.route('/searchvenues').post(async (req, res) => {
  //code here for POST
});

router.route('/venuedetails/:id').get(async (req, res) => {
  //code here for GET
});
