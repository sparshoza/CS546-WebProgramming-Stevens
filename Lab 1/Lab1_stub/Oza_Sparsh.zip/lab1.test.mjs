import * as lab1 from './lab1.mjs';

console.log(lab1.questionOne([51, 6, 11]));  
console.log(lab1.questionOne([2, 1, 2])); 
console.log(lab1.questionOne([52, 17, 189]));
console.log(lab1.questionOne([0, 1, 2])); 
console.log(lab1.questionOne([1, 4, 7, 3])); 



console.log(lab1.questionTwo([1, 2, 3, 4]));   
console.log(lab1.questionTwo([1, 2, 8, 2])); 
console.log(lab1.questionTwo([9, 17, 16, 15])); 
console.log(lab1.questionTwo([26,26,26,25]));
console.log(lab1.questionTwo([123,126,122,105]));


console.log(lab1.questionThree({a1:1,b2:2,c3:3}, {c:10, a:20, b:30}));  
console.log(lab1.questionThree({ada:12,bada:23,cada:34, dada:45}, {f:102, b:203, e:304, d: 405, c:501, a:607})); 
console.log(lab1.questionThree({street:"Some street", city:"Some city", code:"Some postal code"}, {street: "123", city:"hoboken", code:"07307"})); 
console.log(lab1.questionThree({a1:110, b2:120, c3:340, d4: 410, e5:5230, f6:610}, {a1:1,b2:2,c3:3})); 
console.log(lab1.questionThree({test1:110}, {test2:120})); 

console.log(lab1.questionFour(`Patrick,Hill,cs546
Jared,Bass,cs115
Shudong,Hao,cs570`));
console.log(lab1.questionFour(`Exquisite cordially
Delightful, remarkably
taken, the`));
console.log(lab1.questionFour(`Lorem ipsum dolor sit amet,123`));
console.log(lab1.questionFour(`hi,123,no
yes,123,hi,0`));
console.log(lab1.questionFour(`At vero eos et accusamus et
possimus, omnis voluptas assumenda est, omnis dolor`));
