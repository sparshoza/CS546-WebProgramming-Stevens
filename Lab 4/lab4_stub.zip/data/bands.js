// TODO: Export and implement the following functions in ES6 format
const create = async (
  name,
  genre,
  website,
  recordCompany,
  groupMembers,
  yearBandWasFormed
) => {};

const getAll = async () => {};

const get = async (id) => {};

const remove = async (id) => {};

const rename = async (id, newName) => {};
