export const mongoConfig = {
  serverUrl: 'mongodb://localhost:27017/',
  database: 'Sparsh_Oza_lab6'
};