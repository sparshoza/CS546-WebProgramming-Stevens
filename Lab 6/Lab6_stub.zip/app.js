// This file should set up the express server as shown in the lecture code
