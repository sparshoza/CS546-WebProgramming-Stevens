// This data file should export all functions using the ES6 standard as shown in the lecture code

const create = async (
  bandId,
  title,
  releaseDate,
  tracks,
  rating
) => {};

const getAll = async (bandId) => {};

const get = async (albumId) => {};

const remove = async (albumId) => {};
