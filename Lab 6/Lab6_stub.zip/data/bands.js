// This data file should export all functions using the ES6 standard as shown in the lecture code

const create = async (
  name,
  genre,
  website,
  recordCompany,
  groupMembers,
  yearBandWasFormed
) => {};

const getAll = async () => {};

const get = async (id) => {};

const remove = async (id) => {};

const update = async (
  id,
  name,
  genre,
  website,
  recordCompany,
  groupMembers,
  yearBandWasFormed
) => {};
